package com.library.book;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Service;

@Service
public interface Repository extends CrudRepository<Book, Long>{

	@Query("SELECT book FROM Book book")
	Iterable<Book> findAllbooks();


}
